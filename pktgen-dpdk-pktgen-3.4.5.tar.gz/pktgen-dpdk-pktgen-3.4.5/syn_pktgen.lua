package.path = package.path ..";?.lua;test/?.lua;app/?.lua;../?.lua"
require "Pktgen";

URG_FLAG = 0x20;
ACK_FLAG = 0x10;
PSH_FLAG = 0x08;
RST_FLAG = 0x04;
SYN_FLAG = 0x02;
FIN_FLAG = 0x01;

local SendPortNum		= 8;

local dstip		= "192.168.20.77";
local netmask	= "/24";
local srcip		= "192.168.30.1";
local sportrand = 1234
local dportrand = 8000;

local function setupTraffic(i)
	pktgen.set_ipaddr(i, "dst", dstip);
	pktgen.set_ipaddr(i, "src", srcip..netmask);
	pktgen.set(i,"sport",sportrand);
	pktgen.set(i,"dport",dportrand);
	
	pktgen.set_proto( i , "tcp");
	pktgen.set(i, "count", 0);
	pktgen.set(i,"tcptype",SYN_FLAG);
	pktgen.ports_per_page(4);
	--pktgen.set(i,"randadd",1);
end

local function setrandom(i)
	--pktgen.rnd(i, 0, 28, "........XXXXXXXXXXXXXXXXXXXXXXXX",24,128); 
	pktgen.rnd(i, 2, 34, "................XXXXXXXXXXXXXXXX",248,65534); 
end

function main()
	setupTraffic("all");			
	setrandom("all");	
end

main();
