/*-
 * Copyright (c) <2016-2017>, Intel Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/* Created 2016 by Keith Wiles @ intel.com */

#include "pktgen-random.h"

#include <stddef.h>
#include <string.h>
#include <stdio.h>

#include <rte_malloc.h>

#include "pktgen-display.h"
#include "pktgen-log.h"

#include "xorshift64star.h"	/* PRNG function */

/* Allow PRNG function to be changed at runtime for testing*/
#ifdef TESTING
static rnd_func_t _rnd_func = NULL;
#endif

/* Forward declaration */
static void pktgen_init_default_rnd(void);



/**************************************************************************//**
 *
 * pktgen_default_rnd_func - Default function used to generate random values
 *
 * DESCRIPTION
 * Default function to use for generating random values. This function is used
 * when no external random function is set using pktgen_set_rnd_func();
 *
 * RETURNS: 32-bit random value.
 *
 * SEE ALSO:
 */
static __inline__ uint32_t
pktgen_default_rnd_func(void)
{
	return (uint32_t)xorshift64star();
}



/**************************************************************************//**
 *
 * pktgen_rnd_bits_init - Initialize random bitfield structures and PRNG
 *
 * DESCRIPTION
 * Initialize the random bitfield structures the PRNG context.
 *
 * RETURNS: N/A
 *
 * SEE ALSO:
 */

void
pktgen_rnd_bits_init(rnd_bits_t **rnd_bits)
{
	int i;

	*rnd_bits = (rnd_bits_t *)rte_zmalloc_socket(
			"Random bitfield structure",
			sizeof(rnd_bits_t),
			0,
			rte_socket_id());

	/* Initialize mask to all ignore */
	for (i = 0; i < MAX_RND_BITFIELDS; ++i) {
		pktgen_set_random_bitfield(*rnd_bits, i, 0, "????????????????????????????????",0,0);	/* 32 ?'s */
		pktgen_set_random_bitfield(*rnd_bits, i, 0, "",0,0);
	}

	pktgen_init_default_rnd();
}

/**************************************************************************//**
 *
 * pktgen_set_random_bitfield - Set random bit specification
 *
 * DESCRIPTION
 * Set random bit specification. This extracts the 0, 1 and random bitmasks from
 * the provided bitmask template.
 *
 * RETURNS: Active specifications
 *
 * SEE ALSO:
 */

uint32_t
pktgen_set_random_bitfield(rnd_bits_t *rnd_bits,
			   uint8_t idx,
			   uint8_t offset,
			   const char *mask,
			   uint16_t min,
			   uint16_t max)
{
	if (idx >= MAX_RND_BITFIELDS)
		goto leave;

	size_t mask_len = strlen(mask);
	if (mask_len > MAX_BITFIELD_SIZE)
		goto leave;

	/* Disable spec number idx when no mask is specified */
	if (mask_len == 0) {
		rnd_bits->active_specs &= ~((uint32_t)1 << idx);
		goto leave;
	}

	/* Iterate over specified mask from left to right. The mask components are
	 * shifted left and filled at the right side.
	 * When the complete mask has been processed, for each position exactly 1
	 * mask component has a 1 bit set.
	 */
	BITFIELD_T mask0 = 0, mask1 = 0, maskRnd = 0;

	uint32_t i;
	for (i = 0; i < mask_len; ++i) {
		mask0   <<= 1;
		mask1   <<= 1;
		maskRnd <<= 1;

		switch (mask[i]) {
			case '0': mask0   += 1; break;
			case '1': mask1   += 1; break;
			case '.': /* ignore bit */ break;
			case 'x':
			case 'X': maskRnd += 1; break;
			default:/* print error: "Unknown char in bitfield spec" */
				goto
				leave;
		}
	}

	/* Shift bitmasks to MSB position, so the bitmask starts at the provided
	 * offset.
	 * This way the mask can be used as a full-width BITFIELD_T, even when the
	 * provided mask is shorter than the number of bits a BITFIELD_T can store.
	 将位掩码移到MSB位置，因此位掩码从所提供的偏移量开始。
	 通过这种方式，可以将掩码用作全宽度的BITFIELD_T，即使提供的掩码比BITFIELD_T所能存储的比特数要短。
	 */
	int pad_len = MAX_BITFIELD_SIZE - mask_len;
	mask0   <<= pad_len;
	mask1   <<= pad_len;
	maskRnd <<= pad_len;

	rnd_bits->active_specs |= (1 << idx);

	rnd_bits->specs[idx].offset  = offset;

	/* andMask is used to clear certain bits. Bits corresponding to a 1 bit in
	 * the mask will retain their original value, bits corresponding to a 0 bit
	 * in the mask will be cleared.
	 *
	 * - mask0: all set bits in this mask must be 0 in the result
	 * - maskRnd: all set bits in this mask will be zero'd. This enables merging
	 *       of a random value by doing a bitwise OR with the random value.
	 */
	rnd_bits->specs[idx].andMask = htonl(~(mask0 | maskRnd));

	/* orMask is used to set certain bits.
	 */
	rnd_bits->specs[idx].orMask  = htonl(mask1);

	/* rndMask is used to filter a generated random value, so all bits that
	 * should not be random are 0.
	 * The result of this filtering operation can then be bitwise OR-ed with
	 * the original value to merge the random value in.
	 * In the original value, the bits that must be random need to be 0. This is
	 * taken care of by taking the rndMask into account for the andMask.
	 */
	rnd_bits->specs[idx].rndMask = htonl(maskRnd);

	rnd_bits->specs[idx].min = min;
	rnd_bits->specs[idx].max = max;
	rnd_bits->specs[idx].current = min;

leave:
	return rnd_bits->active_specs;
}

/**************************************************************************//**
 *
 * pktgen_rnd_bits_apply - 在包中设置随机位域.
 *
 * DESCRIPTION
 * Set bitfields in packet specified packet to random values according to the
 * requested bitfield specification.
 *
 * RETURNS: N/A
 *
 * SEE ALSO:
 */

void
pktgen_rnd_bits_apply(port_info_t *info,
		      struct rte_mbuf **pkts,
		      size_t cnt,
		      rnd_bits_t *rbits)
{
	rnd_bits_t *rnd_bits;
	size_t mbuf_cnt;
	uint32_t active_specs;
	uint8_t *pkt_data_ip;
	uint16_t *pkt_data_port;
	BITFIELD_T rnd_value;
	bf_spec_t *bf_spec;

	/* the info pointer could be null. */
	rnd_bits = (rbits) ? rbits : info->rnd_bitfields;
	if ((active_specs = rnd_bits->active_specs) == 0)
		return;

	for (mbuf_cnt = 0; mbuf_cnt < cnt; ++mbuf_cnt) {
		bf_spec = rnd_bits->specs;

		while (active_specs > 0) {
			if (likely(active_specs & 1) ) {  //随机已槽启动
				/* Get pointer to byte <offset> in mbuf data as uint32_t*, so */
				/* the masks can be applied. */
				
				//pkt_data = (uint32_t *)(&rte_pktmbuf_mtod(pkts[mbuf_cnt], uint8_t *)[bf_spec->offset]);

				//*pkt_data &= bf_spec->andMask;  //置0   //舍弃了该功能
				//*pkt_data |= bf_spec->orMask;	//置1

				//if (bf_spec->rndMask) {
#ifdef TESTING
					/* 允许在测试时设置PRNG */
				rnd_value  = _rnd_func ? _rnd_func() :
							pktgen_default_rnd_func();
#else
					/* ... but allow inlining for production build */
					//rnd_value  = pktgen_default_rnd_func();
					//rnd_value  =  bf_spec->min + ( pktgen_default_rnd_func() % (bf_spec->max- bf_spec->min) );
					rnd_value = bf_spec->current;
					bf_spec->current++;
					if(bf_spec->current > bf_spec->max){
						bf_spec->current = bf_spec->min;
					}				
#endif

					switch (bf_spec->offset)
					{
						case 26:
						case 27:
						case 28:
						case 29:
						case 30:
						case 31:
						case 32:
						case 33:
							pkt_data_ip = (uint8_t *)(&rte_pktmbuf_mtod(pkts[mbuf_cnt], uint8_t *)[bf_spec->offset]);
							*pkt_data_ip = rnd_value;
							break;
						case 34:
						case 36:

							pkt_data_port = (uint16_t *)(&rte_pktmbuf_mtod(pkts[mbuf_cnt], uint8_t *)[bf_spec->offset]);
							*pkt_data_port = htons(rnd_value);  //主机字节转为网络字节
							break;
						
						default:
							rnd_value &= bf_spec->rndMask;
					}					

					//rnd_value &= bf_spec->rndMask;
					//*pkt_data |= rnd_value;
				//}
			}

			++bf_spec;		/* prepare to use next bitfield spec */
			active_specs >>= 1;	/* use next bit in active spec bitfield */
		}

		active_specs = rnd_bits->active_specs;
	}
}

/**************************************************************************//**
 *
 * pktgen_page_random_bitfields - 显示随机位字段数据页.
 *
 * DESCRIPTION
 * Display the random bitfields data page on the screen.
 *
 * RETURNS: N/A
 *
 * SEE ALSO:
 */
void
pktgen_page_random_bitfields(uint32_t print_labels,
			     uint16_t pid,
			     rnd_bits_t *rnd_bits)
{
	uint32_t row, bitmask_idx, i, curr_bit;
	char mask[36];	/* 4*8 bits, 3 delimiter spaces, \0 */
	bf_spec_t *curr_spec;

	if (!print_labels)
		return;

	mask[35] = '\0';
	mask[8] = mask[17] = mask[26] = ' ';

	display_topline("<Random bitfield Page>");

	scrn_printf(1, 3, "Port %d", pid);

	row = PORT_STATE_ROW;

	if (rnd_bits == NULL) {
		scrn_cprintf(
		        10,
		        this_scrn->ncols,
		        "** Port is not active - no random bitfields set **");
		row = 28;
		goto leave;
	}
	/* Header line */
	scrn_printf(
	        row++,
	        1,
	        "%8s %8s %8s  %s",
	        "Index",
	        "Offset",
	        "Act?",
	        "Mask [0=0 bit,1=1 bit,X=random bit,.=ignore]",
	        "min",
	        "max");

	for (bitmask_idx = 0; bitmask_idx < MAX_RND_BITFIELDS; ++bitmask_idx) {
		curr_spec = &rnd_bits->specs[bitmask_idx];

		memset(mask, 0, sizeof(mask));
		memset(mask, ' ', sizeof(mask) - 1);
		/* Compose human readable bitmask representation */
		for (i = 0; i < MAX_BITFIELD_SIZE; ++i) {
			curr_bit = (uint32_t)1 << (MAX_BITFIELD_SIZE - i - 1);

			/* + i >> 3 for space delimiter after every 8 bits.
			 * Need to check rndMask before andMask: for random bits, the
			 * andMask is also 0. */
			mask[i + (i >> 3)] =
				((ntohl(curr_spec->rndMask) & curr_bit) != 0) ? 'X' :
				((ntohl(curr_spec->andMask) & curr_bit) == 0) ? '0' :
				((ntohl(curr_spec->orMask)  & curr_bit) != 0) ? '1' : '.';
		}

		scrn_printf(row++, 1, "%8d %8d %7s   %s   %d  %d",
		        bitmask_idx, curr_spec->offset,
		        (rnd_bits->active_specs & (1 << bitmask_idx)) ? "Yes" : "No",
		        mask,
		        curr_spec->min,curr_spec->max);
	}

leave:
	display_dashline(++row);
}

static void
pktgen_init_default_rnd(void)
{
	FILE *dev_random;

	if ((dev_random = fopen("/dev/urandom", "r")) == NULL) {
		pktgen_log_error("Could not open /dev/urandom for reading");
		return;
	}

	/* Use contents of /dev/urandom as seed for ISAAC */
	if (fread(xor_state, sizeof(xor_state[0]), 1, dev_random) != 2) {
		pktgen_log_error(
			"Could not read enough random data for PRNG seed");
		return;
	}

	fclose(dev_random);
}

#ifdef TESTING
/**************************************************************************//**
 *
 * pktgen_set_rnd_func - Set function to use as random number generator
 *
 * DESCRIPTION
 * Set function to use as random number generator.
 *
 * RETURNS: Previous random number function (or NULL if the default function was
 *          used).
 *
 * SEE ALSO:
 */

rnd_func_t
pktgen_set_rnd_func(rnd_func_t rnd_func)
{
	rnd_func_t prev_rnd_func = _rnd_func;

	_rnd_func = rnd_func;

	return prev_rnd_func;
}

#endif
